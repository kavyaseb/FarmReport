README

Course: cs400
Semester: Summer 2020
Project name: Chalet Cheese Factory
Student Name: Kavya Sebastian

email: ksebastian3@wisc.edu

Bug report/Future work:
-Should be able to accept all date formats
-Should be able to write to a file
-Should be able to edit existing data from table view